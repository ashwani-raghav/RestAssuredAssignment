package stepDefination;

import static org.testng.Assert.assertEquals;

import java.io.File;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class StepDef {
	
	Header acceptHeader;
	RequestSpecification httpReq;
	Response res;
	File body;
	String basePath="C:\\\\Users\\\\IN002G9X\\\\eclipse-workspace\\\\Assignment\\\\src\\\\main\\\\resources\\\\requests\\\\";
	@Given("I want to call Get\\/Put\\/Post\\/Delete APIs")
	public void i_want_to_call_get_put_post_delete_ap_is_with_api_users_and() {
	    // Write code here that turns the phrase above into concrete actions
		RestAssured.baseURI="https://reqres.in/";
		acceptHeader = new Header("Content-Type","application/json");  
		httpReq=RestAssured.given().header(acceptHeader);;
	}

	@When("I send request of type {string} with {string} and {string}")
	public void i_send_request_of_type_get_with_api_users_and_null(String requestType,String uri, String bodyPath) {
	    // Write code here that turns the phrase above into concrete actions	
		body=new File(basePath+bodyPath);
		if (requestType.equals("GET"))
		{
			res=httpReq.get(uri);
		}
		else if (requestType.equals("POST"))
		{
			res=httpReq.body(body).post(uri);
		}
		else if (requestType.equals("PUT"))
		{			
			res=httpReq.body(body).put(uri);
		}
		else if (requestType.equals("DELETE"))
		{
			res=httpReq.delete(uri);
		}
		
		
	}

	@Then("I validate response codes {int}")
	public void i_validate_response_codes(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Stauscode is:"+res.getStatusCode());
		assertEquals(res.getStatusCode(), +int1);
		res.getBody().prettyPrint();
	}

}
